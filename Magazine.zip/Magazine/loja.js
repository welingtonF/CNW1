function produtos(prod){

    let n = parseInt(prod)

    switch(n){
        case 1 :
        let prec = parseFloat(document.querySelector("#preco1").value)
        let qtd1 = parseFloat(document.querySelector("#qtd"))
        let total1 = prec * qtd1
        alert(n)
                    break
    switch(n){
    case 1 :    let prec = parseFloat(document.querySelector("#preco1").value)
        let qtd1 = parseFloat(document.querySelector("#qtd"))
        let total1 = prec * qtd1
        alert(n)
        break
        
                    

    }



    let prec = document.querySelector("#preco1").value
    let qtd = parseInt(document.querySelector("qtd1").value)

    let total = prec * qtd

    alert(prod)
}